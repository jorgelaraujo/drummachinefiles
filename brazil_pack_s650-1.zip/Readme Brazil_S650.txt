Readme File / VOICE & STYLE EXPANSION PACK for PSR-S650

(1) Files
    Enclosed files are different on each Expansion Packs. This Pack offers you the followings.

  "BRAZIL"
    Expansion File (.yep) : YES  
    Readme File(.txt) : YES
    Registration File(.USR) : NO
    Bonus Style File(.sty): YES
    Bonus MIDI Demo File(.mid): NO

(2) How to install Voice & Style Packs in the PSR-S650
    1. Unzip the downloaded files using your preferred computer program.
    2. Copy the unzipped folder "USER FILES" which contains the Voice & Style files (.yep) and registration data (.USR) to the root folder of your USB storage device. 
       Do not rename the files.
       Do not take the files out of the folder they came in.
       Copy the other folders which contain Midi demo files and Bonus styles to the root folder of your USB storage device.
    3. Connect your USB flash storage device to the USB TO DEVICE terminal, and then call up the FILE CONTROL display.
    4. Use the CATEGORY [<<] and [>>] buttons to select [Expansion Pack Installation.]
    5. Use the dial to select the Expansion Pack you want to install. Press the [EXECUTE] button, and press it again to execute the installation.

 When installation of the Voice & Style Expansion Pack is completed, a message will appear prompting you to turn off the power and on again. 
 Turn the power off, and then back on. Now you're ready to use your new Voices & Styles from the Expansion Pack!
 Please consult the owner�fs manual about the separate loading process and usage of Bonus data such as registration banks, Midi Demo Songs, and Bonus styles. 


-- End of File --